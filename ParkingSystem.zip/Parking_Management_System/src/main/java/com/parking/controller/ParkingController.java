package com.parking.controller;
import com.parking.model.ParkingSlot;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
@RestController
@RequestMapping("/api")
@CrossOrigin
public class ParkingController {
    private final Map<Integer, ParkingSlot> slots = new ConcurrentHashMap<>();
    public ParkingController() { for (int i=1; i<=12; i++) slots.put(i, new ParkingSlot(i)); }
    @GetMapping("/slots")
    public List<ParkingSlot> getSlots() { return slots.values().stream().sorted(Comparator.comparingInt(ParkingSlot::getId)).toList(); }
    @GetMapping("/summary")
    public Map<String, Long> summary() {
        long occupied = slots.values().stream().filter(ParkingSlot::isOccupied).count();
        return Map.of("total",(long)slots.size(),"occupied",occupied,"available",slots.size()-occupied);
    }
    @PostMapping("/park")
    public ParkingSlot park(@RequestBody ParkingSlot req) {
        if (req.getVehicleNumber()==null || req.getVehicleNumber().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Vehicle number is required");
        String number=req.getVehicleNumber().trim().toUpperCase();
        if (slots.values().stream().anyMatch(s -> s.isOccupied() && s.getVehicleNumber().equalsIgnoreCase(number)))
            throw new ResponseStatusException(HttpStatus.CONFLICT,"Vehicle is already parked");
        ParkingSlot slot=slots.values().stream().filter(s -> !s.isOccupied()).min(Comparator.comparingInt(ParkingSlot::getId))
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.CONFLICT,"Parking is full"));
        slot.setVehicleNumber(number); slot.setVehicleType(req.getVehicleType()==null?"Car":req.getVehicleType());
        slot.setOwnerName(req.getOwnerName()==null?"":req.getOwnerName().trim()); slot.setEntryTime(System.currentTimeMillis());
        return slot;
    }
    @PostMapping("/exit/{id}")
    public Map<String,Object> exit(@PathVariable int id) {
        ParkingSlot s=slots.get(id);
        if (s==null || !s.isOccupied()) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Slot is empty");
        long hours=Math.max(1,(long)Math.ceil((System.currentTimeMillis()-s.getEntryTime())/3600000.0));
        double rate="Bike".equalsIgnoreCase(s.getVehicleType())?20:"Truck".equalsIgnoreCase(s.getVehicleType())?80:40;
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("slotId",s.getId()); result.put("vehicleNumber",s.getVehicleNumber()); result.put("durationHours",hours); result.put("amount",hours*rate);
        s.setVehicleNumber(null); s.setVehicleType(null); s.setOwnerName(null); s.setEntryTime(0);
        return result;
    }
}
