package com.parking.model;
public class ParkingSlot {
    private int id;
    private String vehicleNumber, vehicleType, ownerName;
    private long entryTime;
    public ParkingSlot() {}
    public ParkingSlot(int id) { this.id = id; }
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }
    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public long getEntryTime() { return entryTime; }
    public void setEntryTime(long entryTime) { this.entryTime = entryTime; }
    public boolean isOccupied() { return vehicleNumber != null && !vehicleNumber.isBlank(); }
}
