# Parking Management System

A responsive Parking Management System built with Java 17, Spring Boot, Maven, HTML, CSS and JavaScript.

## Features
- Dashboard with total, occupied and available slot counts
- Vehicle entry registration and automatic slot allocation
- Duplicate vehicle checks and full-lot validation
- Vehicle exit with time-based parking fee calculation
- Bike, car and truck rates
- Responsive frontend and REST API

## Requirements
- JDK 17 or later
- Maven 3.6 or later
- Internet access for Maven to download dependencies on the first build

## Run locally
1. Extract this ZIP.
2. Open a terminal in the extracted `Parking_Management_System` folder.
3. Run `mvn spring-boot:run`.
4. Visit `http://localhost:8080`.

You can also import the folder as a Maven project in IntelliJ IDEA, Eclipse or Spring Tool Suite and run `com.parking.ParkingManagementApplication`.

## API endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/slots` | List parking slots |
| GET | `/api/summary` | Get parking counts |
| POST | `/api/park` | Register vehicle entry |
| POST | `/api/exit/{id}` | Register exit and calculate fee |

Example JSON for `POST /api/park`:
```json
{
  "vehicleNumber": "TN 37 AB 1234",
  "ownerName": "Sample User",
  "vehicleType": "Car"
}
```

## Demo parking rates
- Bike: ₹20/hour
- Car: ₹40/hour
- Truck: ₹80/hour

Billing rounds up to the next hour, with a minimum charge of one hour. Change the rates in `ParkingController.java` if needed.

## Project structure
```text
Parking_Management_System/
├── pom.xml
├── README.md
└── src/main/
    ├── java/com/parking/
    │   ├── ParkingManagementApplication.java
    │   ├── controller/ParkingController.java
    │   └── model/ParkingSlot.java
    └── resources/static/
        ├── index.html
        ├── style.css
        └── app.js
```

## Note
This is an educational demo. Data is stored in memory and resets when the server restarts. A production version should add persistent database storage, authentication and audit logs.

## GitHub submission
Create a new GitHub repository named `Parking-Management-System`, upload the extracted project files, and update this README with your name, department and college before submitting.
